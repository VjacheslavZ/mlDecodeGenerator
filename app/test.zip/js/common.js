'use strict';

document.addEventListener('DOMContentLoaded', function () {
  var buttonOpenSelect = document.querySelector('.openSelect');
  var select = document.querySelector('.selectMenu');

  buttonOpenSelect.addEventListener('click', function (e) {
    var selectClassList = select.classList;

    if (selectClassList.contains('open')) {
      selectClassList.remove('open');
      return;
    }
    selectClassList.add('open');
  });

  var selectMenuItems = select.querySelectorAll('li');

  var onHandleClickMenu = function onHandleClickMenu(event) {
    var target = event.target;

    var selectedMenuValue = target.innerText;
    buttonOpenSelect.innerHTML = selectedMenuValue;

    select.querySelector('.selected').classList.remove('selected');

    target.classList.add('selected');
  };

  selectMenuItems.forEach(function (menu) {
    menu.addEventListener('click', onHandleClickMenu);
  });

  var body = document.querySelector('body');
  body.addEventListener('click', function (event) {
    var target = event.target;

    if (!target.classList.contains('openSelect')) {
      select.classList.remove('open');
    }
  });
});