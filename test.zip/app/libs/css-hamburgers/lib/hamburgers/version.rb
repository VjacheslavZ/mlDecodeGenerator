module Hamburgers
  VERSION = "0.9.1"
end
