document.addEventListener('DOMContentLoaded', function(){
  const buttonOpenSelect = document.querySelector('.openSelect');
  const select = document.querySelector('.selectMenu');

  buttonOpenSelect.addEventListener('click', function (e) {
    const selectClassList = select.classList;

    if(selectClassList.contains('open')) {
      selectClassList.remove('open');
      return ;
    }
    selectClassList.add('open');
  });

  const selectMenuItems = select.querySelectorAll('li');

  const onHandleClickMenu = (event) => {
    const { target } = event;
    const selectedMenuValue = target.innerText;
    buttonOpenSelect.innerHTML = selectedMenuValue;

    select.querySelector('.selected').classList.remove('selected');

    target.classList.add('selected');
  };

  selectMenuItems.forEach(menu => {
    menu.addEventListener('click', onHandleClickMenu)
  })


  const body = document.querySelector('body')
  body.addEventListener('click', (event) => {
    const { target } = event;
    if(!target.classList.contains('openSelect')) {
      select.classList.remove('open')
    }
  })
});
